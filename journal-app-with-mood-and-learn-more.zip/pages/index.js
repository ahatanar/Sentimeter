
import Link from 'next/link';
import Head from 'next/head';

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col bg-light-pattern bg-cover text-center items-center">
      <Head>
        <title>Journal App</title>
      </Head>
      {/* Navbar */}
      <nav className="w-full flex justify-between px-6 py-4 bg-white shadow-md">
        <img src="/logo.png" alt="App Logo" className="w-12 h-12" />
        <div className="flex gap-4">
          <Link href="#" className="text-gray-800 hover:text-orange-500">Home</Link>
          <Link href="#" className="text-gray-800 hover:text-orange-500">Collections</Link>
          <Link href="/dashboard" className="bg-orange-500 text-white px-4 py-2 rounded-md hover:bg-orange-600">
            Dashboard
          </Link>
          <Link href="/signin" className="text-gray-800 hover:text-orange-500">Sign In</Link>
        </div>
      </nav>
      {/* Main Content */}
      <div className="flex flex-col items-center mt-12">
        <h1 className="text-4xl font-bold text-orange-600 mb-4">Your Space to Reflect.</h1>
        <h2 className="text-2xl font-semibold text-gray-700 mb-6">Your Story to Tell.</h2>
        <p className="text-gray-600 max-w-2xl mb-8">
          Capture your thoughts, track your moods, and reflect on your journey in a beautiful, secure space.
        </p>
        <div className="flex gap-4">
          <Link href="/signin">
            <button className="px-6 py-2 bg-orange-500 text-white rounded-md hover:bg-orange-600">
              Start Writing
            </button>
          </Link>
          <Link href="/learn-more">
            <button className="px-6 py-2 bg-gray-200 text-gray-700 rounded-md hover:bg-gray-300">
              Learn More
            </button>
          </Link>
        </div>
      </div>
    </div>
  );
}
