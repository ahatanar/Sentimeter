
import Head from 'next/head';
import Link from 'next/link';

export default function Dashboard() {
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col items-center py-10">
      <Head>
        <title>Dashboard</title>
      </Head>
      <div className="flex justify-between w-1/2 mb-4">
        <Link href="/">
          <button className="px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600">
            Go Back to Home
          </button>
        </Link>
        <button className="px-4 py-2 bg-red-500 text-white rounded-md hover:bg-red-600">
          Sign Out
        </button>
      </div>
      <h1 className="text-2xl font-bold mb-6">Your Dashboard</h1>
      <form className="w-1/2 bg-white shadow-md p-6 rounded-md">
        <label className="block text-gray-700 mb-2">Journal Title</label>
        <input
          type="text"
          placeholder="Enter title..."
          className="w-full mb-4 px-3 py-2 border rounded-md"
        />
        <label className="block text-gray-700 mb-2">How are you feeling?</label>
        <select className="w-full mb-4 px-3 py-2 border rounded-md">
          <option value="happy">Happy</option>
          <option value="sad">Sad</option>
          <option value="angry">Angry</option>
          <option value="excited">Excited</option>
          <option value="neutral">Neutral</option>
        </select>
        <label className="block text-gray-700 mb-2">Journal Content</label>
        <textarea
          placeholder="Write your journal here..."
          className="w-full mb-4 px-3 py-2 border rounded-md h-32"
        ></textarea>
        <button
          type="button"
          className="px-4 py-2 bg-green-500 text-white rounded-md hover:bg-green-600"
        >
          Save Journal
        </button>
      </form>
    </div>
  );
}
